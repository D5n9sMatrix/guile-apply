<!-- 
    The format to be used for data in the $desc array is the same as returned 
    by calls to function `xmlrpc_parse_method_descriptions`
-->

<?php
 xmlrpc_server_add_introspection_data(resource $server, array $desc): int
?> 