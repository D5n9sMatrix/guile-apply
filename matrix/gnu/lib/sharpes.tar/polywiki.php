<!-- auto office -->
<?php
__autoload
?>
<?php
xmlrpc_encode(mixed $value): string
?>
