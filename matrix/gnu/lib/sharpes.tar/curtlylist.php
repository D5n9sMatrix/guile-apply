<!--
    All curtly call message platform ...
--> 
    
<?php
 xmlrpc_server_create(): resource
?> 