<?php
// The PHP XML-RPC project at SourceForge makes life a hell of a lot easier. 
// However, the project uses some function names which are identical to those 
// provided by the XML-RPC extension.

// If you are on a server with XML-RPC extension compiled in but wish to use the PHP 
// based version then you will have to rename some of the functions.

// I notice that sourceforge says there is activity on the project in 2005 but the 
// last release was January 12, 2003.

// I recommend that you use this not so friendly PHP extension if available. 
// However this sourceforge project is still a good idea if you don't control 
// which extensions are be available on the server.

// http://phpxmlrpc.sourceforge.net/
?>
