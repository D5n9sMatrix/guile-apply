<?php
// An alternative XML-RPC implementation is available 
// at http://xmlrpc.usefulinc.com - it's written in PHP 
// so you can use it on servers for which you don't have 
// the luxury of rebuilding PHP on.

// nic
?>
