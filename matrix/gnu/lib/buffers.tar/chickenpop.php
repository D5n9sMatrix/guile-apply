<?php
// If you need to use this extension but are stuck on a server where 
// it can not be installed, the php-xmlrpc library found 
// at http://phpxmlrpc.sourceforge.net includes an emulation 
// layer that aims to be 100% compatible with the API of the native 
// extension (as part of the "extras" package since version 0.2).
// This means your code should be able to run unmodified on top of 
// the php-xmlrpc library. Of course performance will be at least 
// an order of magnitude worse...
?>