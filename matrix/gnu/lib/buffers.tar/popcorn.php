<?php
// For a really easy way to use this XML-RPC extension 
// take a look at

// XML-RPC Class Server (http://www.webkreator.com/php/xcs/)

// It automatically creates servers out of PHP classes. Creating 
// clients is almost as easy, especially with the recent addition 
// of the overload extension to 
// PHP (see http://www.php.net/manual/en/ref.overload.php).
?>
