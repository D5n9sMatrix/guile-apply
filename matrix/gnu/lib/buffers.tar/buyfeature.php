<?php
// This extension does not handle the process of making making XML-RPC 
// client requests via HTTP; it only prepares the XML-RPC request 
// payload.

// This differs from many other XML-RPC implementations but offers 
// greater flexibility, allowing SSL connections, authentication 
// headers and XML-RPC via other transports like SMTP.
?>
